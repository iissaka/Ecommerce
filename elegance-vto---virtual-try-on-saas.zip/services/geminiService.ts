
import { GoogleGenAI } from "@google/genai";

/**
 * GeminiService handles the "Image-to-Image" processing using Nano Banana.
 * It takes the user's silhouette and a description of the garment to generate
 * a realistic virtual try-on result.
 */
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  /**
   * Generates a virtual try-on image.
   * @param userImageBase64 The base64 encoded image of the user.
   * @param garmentDescription Description of the garment (name, color, material).
   * @returns Base64 encoded string of the resulting image.
   */
  async performVirtualTryOn(userImageBase64: string, garmentDescription: string): Promise<string> {
    // We use gemini-2.5-flash-image for image editing / generation
    const model = 'gemini-2.5-flash-image';
    
    // Detailed prompt to ensure the model handles textures, shadows, and folds correctly.
    // The model treats the input image as a reference and generates the outfit on top.
    const prompt = `
      Perform a virtual try-on. 
      Apply the following garment to the person in the provided image: ${garmentDescription}.
      Requirements:
      1. Maintain the identity, pose, and silhouette of the person in the image.
      2. The garment should fit naturally, showing realistic fabric textures (e.g., silk, wool, velvet).
      3. Accurately render shadows, highlights, and folds that correspond to the person's pose and the original lighting environment.
      4. Ensure the edges where the clothing meets the skin or background are seamless.
      5. The final output should look like a high-end commercial fashion photograph.
    `;

    const response = await this.ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              data: userImageBase64.split(',')[1], // Strip metadata prefix if present
              mimeType: 'image/png',
            },
          },
          { text: prompt },
        ],
      },
    });

    let resultBase64 = '';
    
    // Iterate through response parts to find the generated image
    if (response.candidates && response.candidates[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          resultBase64 = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!resultBase64) {
      throw new Error("Failed to generate the virtual try-on image. The model did not return an image part.");
    }

    return resultBase64;
  }
}

export const geminiService = new GeminiService();
