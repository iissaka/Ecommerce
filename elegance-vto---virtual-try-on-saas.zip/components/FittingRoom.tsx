
import React from 'react';
import { Product } from '../types';

interface FittingRoomProps {
  product: Product;
  userImage: string;
  selectedColor: string;
  selectedSize: string;
  onColorChange: (color: string) => void;
  onSizeChange: (size: string) => void;
  onTryOn: () => void;
  onBack: () => void;
  isProcessing: boolean;
}

const FittingRoom: React.FC<FittingRoomProps> = ({
  product,
  userImage,
  selectedColor,
  selectedSize,
  onColorChange,
  onSizeChange,
  onTryOn,
  onBack,
  isProcessing
}) => {
  return (
    <div className="animate-in fade-in duration-700 flex flex-col lg:flex-row gap-12 items-start">
      <div className="w-full lg:w-1/2">
        <div className="relative rounded-3xl overflow-hidden aspect-[4/5] bg-gray-100 shadow-2xl">
          <img src={userImage} alt="User" className="w-full h-full object-cover opacity-80" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6">
            <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-[10px] font-bold text-white uppercase tracking-widest mb-2">Reference Image</span>
            <p className="text-white text-sm opacity-80">Ready for fitting...</p>
          </div>
          
          {isProcessing && (
            <div className="absolute inset-0 bg-white/60 backdrop-blur-sm flex flex-col items-center justify-center p-8 text-center">
              <div className="relative mb-6">
                <div className="w-16 h-16 border-4 border-black/10 border-t-black rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="w-2 h-2 bg-black rounded-full animate-pulse"></div>
                </div>
              </div>
              <h4 className="text-2xl font-serif text-gray-900 mb-3 animate-pulse">Tailoring your look...</h4>
              <p className="text-sm text-gray-600 max-w-xs leading-relaxed">
                Our AI is precisely mapping the {product.name.toLowerCase()}'s fabric, shadows, and drapes to your silhouette.
              </p>
            </div>
          )}
        </div>
      </div>

      <div className="w-full lg:w-1/2 space-y-10">
        <div>
          <button onClick={onBack} className="mb-6 text-sm text-gray-400 hover:text-black transition-colors flex items-center space-x-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
            <span>Back to Collection</span>
          </button>
          <h2 className="text-4xl font-serif text-gray-900 mb-2">{product.name}</h2>
          <p className="text-2xl font-medium text-gray-500">{product.price}</p>
          <p className="mt-6 text-gray-600 leading-relaxed text-lg italic">
            &ldquo;{product.description}&rdquo;
          </p>
        </div>

        <div className="space-y-8">
          {/* Color Selector */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-4">Color: {selectedColor}</h4>
            <div className="flex flex-wrap gap-3">
              {product.colors.map((color) => (
                <button
                  key={color.name}
                  onClick={() => onColorChange(color.name)}
                  className={`relative w-12 h-12 rounded-full border-2 transition-all flex items-center justify-center ${
                    selectedColor === color.name ? 'border-black scale-110' : 'border-transparent hover:scale-105'
                  }`}
                  title={color.name}
                >
                  <span 
                    className="w-8 h-8 rounded-full border border-gray-100 shadow-inner" 
                    style={{ backgroundColor: color.hex }} 
                  />
                  {selectedColor === color.name && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-black rounded-full flex items-center justify-center">
                      <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Size Selector */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-4">Size: {selectedSize}</h4>
            <div className="flex flex-wrap gap-3">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => onSizeChange(size)}
                  className={`px-5 py-2.5 text-sm font-medium rounded-xl border transition-all ${
                    selectedSize === size 
                    ? 'border-black bg-black text-white shadow-md' 
                    : 'border-gray-200 text-gray-600 hover:border-gray-900'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8">
          <button 
            disabled={isProcessing}
            onClick={onTryOn}
            className="w-full py-5 bg-black text-white rounded-full font-bold uppercase tracking-widest shadow-2xl hover:bg-gray-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            <span className="flex items-center justify-center space-x-2">
              <span>{isProcessing ? 'Processing' : 'Generate Virtual Fitting'}</span>
              {!isProcessing && (
                <svg className="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              )}
            </span>
          </button>
          <p className="text-center mt-4 text-xs text-gray-400">Powered by Nano Banana & Elegance Cloud</p>
        </div>
      </div>
    </div>
  );
};

export default FittingRoom;
