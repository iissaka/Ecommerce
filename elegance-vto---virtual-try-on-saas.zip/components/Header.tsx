
import React from 'react';

interface HeaderProps {
  onLogoClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogoClick }) => {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div 
          className="flex items-center space-x-2 cursor-pointer group"
          onClick={onLogoClick}
        >
          <div className="w-8 h-8 bg-black rounded-full flex items-center justify-center transition-transform group-hover:scale-110">
            <span className="text-white font-serif text-xl">E</span>
          </div>
          <span className="text-xl font-serif tracking-widest text-gray-900 uppercase">Elegance VTO</span>
        </div>
        
        <nav className="hidden md:flex space-x-8">
          <a href="#" className="text-sm font-medium text-gray-600 hover:text-black transition-colors uppercase tracking-tight">Collection</a>
          <a href="#" className="text-sm font-medium text-gray-600 hover:text-black transition-colors uppercase tracking-tight">Bespoke</a>
          <a href="#" className="text-sm font-medium text-gray-600 hover:text-black transition-colors uppercase tracking-tight">About</a>
        </nav>

        <div className="flex items-center space-x-4">
          <button className="p-2 text-gray-400 hover:text-black transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </button>
          <button className="p-2 text-gray-400 hover:text-black transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
