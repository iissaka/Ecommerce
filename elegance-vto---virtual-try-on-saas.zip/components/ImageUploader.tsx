
import React, { useRef } from 'react';

interface ImageUploaderProps {
  onUpload: (base64: string) => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpload(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full max-w-xl group">
      <div 
        onClick={triggerUpload}
        className="relative overflow-hidden border-2 border-dashed border-gray-200 rounded-3xl aspect-[4/5] sm:aspect-[3/2] flex flex-col items-center justify-center p-8 cursor-pointer transition-all hover:border-black hover:bg-gray-50 bg-white"
      >
        <div className="w-16 h-16 mb-4 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 group-hover:text-black group-hover:bg-white transition-all shadow-sm">
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
        </div>
        <h3 className="text-xl font-medium mb-2 text-gray-900">Upload your portrait</h3>
        <p className="text-sm text-gray-500 text-center max-w-xs px-4">
          For best results, use a full-body photo with good lighting and a simple background.
        </p>
        
        <input 
          ref={fileInputRef}
          type="file" 
          accept="image/*" 
          onChange={handleFileChange} 
          className="hidden" 
        />
        
        <div className="mt-8 px-8 py-3 bg-black text-white text-sm font-medium rounded-full shadow-lg hover:bg-gray-800 transition-all opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0">
          Choose File
        </div>
      </div>
      
      <div className="mt-8 grid grid-cols-2 gap-4">
        <div className="p-4 bg-white rounded-2xl border border-gray-100 flex items-start space-x-3">
          <div className="mt-1 w-5 h-5 flex-shrink-0 bg-gray-100 rounded-full flex items-center justify-center text-[10px] font-bold">1</div>
          <p className="text-xs text-gray-500">Stand straight with hands by your side for the most accurate fabric simulation.</p>
        </div>
        <div className="p-4 bg-white rounded-2xl border border-gray-100 flex items-start space-x-3">
          <div className="mt-1 w-5 h-5 flex-shrink-0 bg-gray-100 rounded-full flex items-center justify-center text-[10px] font-bold">2</div>
          <p className="text-xs text-gray-500">Ensure your silhouette is clearly visible against a contrasting background.</p>
        </div>
      </div>
    </div>
  );
};

export default ImageUploader;
