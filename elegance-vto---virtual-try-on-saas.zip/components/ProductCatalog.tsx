
import React from 'react';
import { Product } from '../types';

interface ProductCatalogProps {
  products: Product[];
  onSelect: (product: Product) => void;
  onBack: () => void;
}

const ProductCatalog: React.FC<ProductCatalogProps> = ({ products, onSelect, onBack }) => {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-serif text-gray-900">The Season's Edit</h2>
          <p className="text-gray-500 mt-1">Select a piece to begin your virtual fitting.</p>
        </div>
        <button 
          onClick={onBack}
          className="text-sm font-medium text-gray-500 hover:text-black flex items-center space-x-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
          <span>Change Photo</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {products.map((product) => (
          <div 
            key={product.id}
            className="group cursor-pointer"
            onClick={() => onSelect(product)}
          >
            <div className="relative aspect-[3/4] overflow-hidden rounded-2xl mb-4 bg-gray-100">
              <img 
                src={product.thumbnail} 
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors" />
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-6 py-2 bg-white text-black text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all rounded-full shadow-xl">
                Try It On
              </div>
            </div>
            <div className="space-y-1">
              <h3 className="font-medium text-gray-900">{product.name}</h3>
              <p className="text-xs text-gray-400 uppercase tracking-widest">{product.category}</p>
              <p className="text-sm font-medium text-gray-600">{product.price}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductCatalog;
