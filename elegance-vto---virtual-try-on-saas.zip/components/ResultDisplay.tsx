
import React from 'react';
import { TryOnResult, Product } from '../types';

interface ResultDisplayProps {
  result: TryOnResult;
  product: Product;
  onBack: () => void;
  onRestart: () => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, product, onBack, onRestart }) => {
  return (
    <div className="animate-in fade-in duration-1000">
      <div className="flex flex-col lg:flex-row gap-12 items-start">
        <div className="w-full lg:w-2/3">
          <div className="relative rounded-[2rem] overflow-hidden bg-white shadow-2xl shadow-black/10 group">
            <img 
              src={result.imageUrl} 
              alt="Virtual Try-On Result" 
              className="w-full h-auto object-cover"
            />
            <div className="absolute top-6 left-6">
              <span className="px-4 py-1.5 bg-black/80 backdrop-blur-md rounded-full text-[10px] font-bold text-white uppercase tracking-widest border border-white/20">
                AI Generation - High Fidelity
              </span>
            </div>
            
            <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity cursor-zoom-in" />
            
            <div className="absolute bottom-6 right-6 flex space-x-2">
               <button className="p-3 bg-white/90 backdrop-blur-md rounded-full shadow-lg hover:bg-white transition-colors">
                  <svg className="w-5 h-5 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
               </button>
               <button className="p-3 bg-white/90 backdrop-blur-md rounded-full shadow-lg hover:bg-white transition-colors">
                  <svg className="w-5 h-5 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
               </button>
            </div>
          </div>
        </div>

        <div className="w-full lg:w-1/3 flex flex-col space-y-8">
          <div className="space-y-4">
            <h2 className="text-3xl font-serif text-gray-900">It's a perfect match.</h2>
            <div className="p-6 bg-white rounded-2xl border border-gray-100 shadow-sm flex items-center space-x-4">
               <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                  <img src={product.thumbnail} className="w-full h-full object-cover" alt={product.name} />
               </div>
               <div>
                  <h4 className="font-bold text-gray-900">{product.name}</h4>
                  <p className="text-sm text-gray-500">{result.color} &bull; Size {product.sizes[0]}</p>
                  <p className="text-sm font-semibold text-black mt-1">{product.price}</p>
               </div>
            </div>
          </div>

          <div className="space-y-4">
             <button className="w-full py-5 bg-black text-white rounded-full font-bold uppercase tracking-widest shadow-xl hover:bg-gray-800 transition-all">
                Add to Cart
             </button>
             <button className="w-full py-5 bg-white border border-gray-200 text-black rounded-full font-bold uppercase tracking-widest hover:border-black transition-all">
                Find in Store
             </button>
          </div>

          <div className="pt-8 border-t border-gray-100">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-6">Explore more options</h4>
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={onBack}
                className="flex flex-col items-center justify-center p-6 bg-gray-50 rounded-2xl border border-transparent hover:border-black transition-all group"
              >
                <svg className="w-6 h-6 mb-2 text-gray-400 group-hover:text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>
                <span className="text-xs font-bold uppercase tracking-tighter text-gray-900">Modify Look</span>
              </button>
              <button 
                onClick={onRestart}
                className="flex flex-col items-center justify-center p-6 bg-gray-50 rounded-2xl border border-transparent hover:border-black transition-all group"
              >
                <svg className="w-6 h-6 mb-2 text-gray-400 group-hover:text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                <span className="text-xs font-bold uppercase tracking-tighter text-gray-900">New Photo</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultDisplay;
